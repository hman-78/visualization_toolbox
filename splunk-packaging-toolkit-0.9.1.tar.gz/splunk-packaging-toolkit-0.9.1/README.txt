SPLUNK PACKAGING TOOLKIT 0.9.1 (Beta)
January 2017

The Splunk Packaging Toolkit offers a tool for authoring, packaging and validating a Splunk app in a way that eases up app installation, configuration, and update.

Splunk Packaging Toolkit online documentation is located at:
* http://dev.splunk.com/goto/packaging-toolkit

For installation instructions, see:
* http://dev.splunk.com/goto/packaging-toolkit-install

For release notes, see:
* http://dev.splunk.com/goto/packaging-toolkit-rn

Send your feedback to: appmgmt-feedback@splunk.com or via answers.splunk.com