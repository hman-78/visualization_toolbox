#!/usr/bin/env python
# coding=utf-8
#
# Copyright © Splunk, Inc. All Rights Reserved.

from __future__ import absolute_import, division, print_function, unicode_literals

from os import path
import json
import sys

from slim.utils import *
from slim.app import *
from slim.command import *

# Argument parser definition

parser = SlimArgumentParser(
    description='perform a sequence of update actions on an installation graph',
    epilog='''Update actions are defined as a sequence of JSON objects as illustrated below:

  --actions '{
    "action": "add",
    "args": {
      "app_package": "<path>",
      "combine_search_head_indexer_workloads": <boolean>,
        "workloads": {
          "<input-group-name>": ["<server-class-name>"(, "<server-class-name>" ...)],
          "<input-group-name>": ["<server-class-name>"(, "<server-class-name>" ...)] ...
        }
      }
    }
  }' '{
    "action": "remove",
      "args": {
        "app_id": "<app_id>"
      }
    }
  }' '{
    "action": "set",
    "args": {
      "app_package": "<path>",
        "combine_search_head_indexer_workloads": <boolean>,
        "workloads": {
          "<input-group-name>": ["<server-class-name>"(, "<server-class-name>" ...)],
          "<input-group-name>": ["<server-class-name>"(, "<server-class-name>" ...)] ...
        }
      }
    }
  }' '{
    "action": "update"
    "args": {
      "app_package": "<path>"
    }
  }'
''')

parser.add_argument_help()
parser.add_installation()
parser.add_output_directory(description='installation graph and deployment packages')
parser.add_repository()

# Command-specific arguments

parser.add_argument(
    '-a', '--actions',
    type=SlimInstallationActionArgument(), nargs='+', default=[],
    help='apply actions to the given installation graph: add, remove, set, or update',
    metavar='<action>')

parser.add_argument(
    '--disable-automatic-resolution',
    action='store_const', const=True, default=False,
    help='do not automatically resolve dependency conflicts by updating installed versions')


def main(args):

    server_collection = _update_installation(
        args.installation, args.repository, args.actions, args.disable_automatic_resolution
    )

    filename = path.join(args.output_dir, 'installation-update.json')
    server_collection.save(filename)
    SlimLogger.exit_on_error()
    SlimLogger.information('Saved updated installation graph to ', encode_filename(filename))


def update_installation(installation_graph, action_list, disable_automatic_resolution=False):

    if isinstance(installation_graph, dict):
        installation_graph = json.dumps(installation_graph)

    stream_type = SlimStringIOArgument(name="installation_graph.json")

    with stream_type(value=installation_graph) as istream:
        action_type = SlimInstallationActionArgument()
        actions = []
        for action in action_list:
            actions.append(action_type(value=json.dumps(action)))

        server_collection = _update_installation(
            istream, slim_configuration.repository_path, actions, disable_automatic_resolution
        )

    # Save the installation graph to the payload only (not file output)
    server_collection.save(None)
    SlimLogger.exit_on_error()


# pylint: disable=redefined-builtin
def _update_installation(file, repository, actions, disable_automatic_resolution):

    SlimLogger.step('Updating installation graph at ', encode_filename(file.name))

    server_collection = AppServerClassCollection.load(file, repository)
    SlimLogger.exit_on_error()

    # Disable installation graph update validation until all actions have been complete
    server_collection.validate = False

    for action in actions:
        server_collection.update_installation(action, disable_automatic_resolution)
        SlimLogger.exit_on_error()

    # Enable installation graph validation again, and trigger a reload
    server_collection.validate = True
    server_collection.reload()
    SlimLogger.exit_on_error()

    return server_collection


if __name__ == '__main__':
    # noinspection PyBroadException
    try:
        main(parser.parse_args(sys.argv[1:]))
    except SystemExit:
        raise
    except:
        SlimLogger.fatal(exception_info=sys.exc_info())
